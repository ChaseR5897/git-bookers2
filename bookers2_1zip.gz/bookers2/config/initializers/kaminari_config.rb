Kaminari.configure do |config|


  config.default_per_page = 5
end