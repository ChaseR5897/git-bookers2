# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '624e545d084144b322a28b333741a223f4b43d1150094f6dfa4df8912cf17554f25daa371cdf60bd3f0eb3f4eeb1beb766e752ba412b4a4d068905a19a7db51f'